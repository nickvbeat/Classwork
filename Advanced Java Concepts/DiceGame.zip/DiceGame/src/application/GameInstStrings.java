package application;

public class GameInstStrings {
	
	public String name, win;
	
	public GameInstStrings(String name, String win) {
		this.name=name;
		this.win=win;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWin() {
		return win;
	}

	public void setWin(String win) {
		this.win = win;
	}
}

